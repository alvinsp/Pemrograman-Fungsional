import matplotlib. pyplot as plt
import numpy as np

x = [1, 2, 3, 4, 5, 10, 8]
y = [3, 7, 2, 8, 5, 7, 4]

plt.scatter(x, y)
plt.show()